<?php
// Konfigurasi koneksi ke database
require_once('config.php');

// Fungsi untuk mengambil jadwal ruangan
function getJadwalData($conn) {
    $sql = "SELECT j.id_jadwal, r.nama_ruangan, j.tanggal, j.waktu_mulai, j.waktu_selesai, j.keterangan
            FROM jadwal_ruangan j
            JOIN ruangan r ON j.id_ruangan = r.id_ruangan
            ORDER BY j.tanggal, j.waktu_mulai ASC";
    $result = $conn->query($sql);
    return $result;
}

// Menampilkan data jadwal
function displayJadwalData($result) {
    if ($result->num_rows > 0) {
        echo "<table class='table table-striped'>";
        echo "<thead><tr><th>ID Jadwal</th><th>Nama Ruangan</th><th>Tanggal</th><th>Waktu Mulai</th><th>Waktu Selesai</th><th>Keterangan</th></tr></thead>";
        echo "<tbody>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row["id_jadwal"] . "</td>";
            echo "<td>" . $row["nama_ruangan"] . "</td>";
            echo "<td>" . $row["tanggal"] . "</td>";
            echo "<td>" . $row["waktu_mulai"] . "</td>";
            echo "<td>" . $row["waktu_selesai"] . "</td>";
            echo "<td>" . $row["keterangan"] . "</td>";
            echo "</tr>";
        }
        echo "</tbody>";
        echo "</table>";
    } else {
        echo "<p>Tidak ada jadwal yang tersedia.</p>";
    }
}

// Mengambil data jadwal
$result = getJadwalData($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Daftar Jadwal Ruangan</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <h2>Daftar Jadwal Ruangan</h2>
        <?php displayJadwalData($result); ?>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
