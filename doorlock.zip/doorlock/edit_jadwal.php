<?php
require_once('config.php');

if (isset($_GET['id_jadwal'])) {
    $id_jadwal = $_GET['id_jadwal'];
    
    // Ambil data jadwal yang akan diedit
    $sql = "SELECT * FROM jadwal_ruangan WHERE id_jadwal = ?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $id_jadwal);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $id_ruangan = $row['id_ruangan'];
            $tanggal = $row['tanggal'];
            $waktu_mulai = $row['waktu_mulai'];
            $waktu_selesai = $row['waktu_selesai'];
            $keterangan = $row['keterangan'];
        } else {
            echo "<script>alert('Jadwal tidak ditemukan.'); window.location.href='jadwal_ruangan.php';</script>";
            exit();
        }
        $stmt->close();
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Update data jadwal
    $id_jadwal = $_POST["id_jadwal"];
    $id_ruangan = $_POST["id_ruangan"];
    $tanggal = $_POST["tanggal"];
    $waktu_mulai = $_POST["waktu_mulai"];
    $waktu_selesai = $_POST["waktu_selesai"];
    $keterangan = $_POST["keterangan"];

    $sql = "UPDATE jadwal_ruangan SET id_ruangan = ?, tanggal = ?, waktu_mulai = ?, waktu_selesai = ?, keterangan = ? WHERE id_jadwal = ?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("issssi", $id_ruangan, $tanggal, $waktu_mulai, $waktu_selesai, $keterangan, $id_jadwal);
        if ($stmt->execute()) {
            echo "<script>alert('Jadwal berhasil diperbarui.'); window.location.href='jadwal_ruangan.php';</script>";
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Jadwal Ruangan</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            width: 100%;
            max-width: 600px;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .container h2 {
            margin-bottom: 20px;
            font-size: 24px;
            text-align: center;
            color: #333;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 8px;
            color: #555;
        }

        .form-group input[type="text"],
        .form-group input[type="date"],
        .form-group input[type="time"] {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            transition: border-color 0.3s;
        }

        .form-group input[type="text"]:focus,
        .form-group input[type="date"]:focus,
        .form-group input[type="time"]:focus {
            border-color: #4caf50;
            outline: none;
        }

        .buttons {
            display: flex;
            justify-content: space-between;
        }

        .form-group button,
        .cancel-btn {
            background-color: #4caf50;
            color: white;
            border: none;
            padding: 12px 20px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .form-group button:hover,
        .cancel-btn:hover {
            background-color: #45a049;
        }

        .cancel-btn {
            background-color: #d9534f;
        }

        .cancel-btn:hover {
            background-color: #c9302c;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Edit Jadwal Ruangan</h2>
        <form action="edit_jadwal.php" method="POST">
            <input type="hidden" name="id_jadwal" value="<?php echo $id_jadwal; ?>">
            <div class="form-group">
                <label for="id_ruangan">Ruangan:</label>
                <input type="text" name="id_ruangan" value="<?php echo $id_ruangan; ?>" required>
            </div>
            <div class="form-group">
                <label for="tanggal">Tanggal:</label>
                <input type="date" name="tanggal" value="<?php echo $tanggal; ?>" required>
            </div>
            <div class="form-group">
                <label for="waktu_mulai">Waktu Mulai:</label>
                <input type="time" name="waktu_mulai" value="<?php echo $waktu_mulai; ?>" required>
            </div>
            <div class="form-group">
                <label for="waktu_selesai">Waktu Selesai:</label>
                <input type="time" name="waktu_selesai" value="<?php echo $waktu_selesai; ?>" required>
            </div>
            <div class="form-group">
                <label for="keterangan">Keterangan:</label>
                <input type="text" name="keterangan" value="<?php echo $keterangan; ?>">
            </div>
            <div class="buttons">
                <button type="submit">Perbarui</button>
                <button type="button" class="cancel-btn" onclick="window.location.href='jadwal_ruangan.php';">Batal</button>
            </div>
        </form>
    </div>
</body>
</html>
