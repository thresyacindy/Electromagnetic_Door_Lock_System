<?php
// Memulai sesi
session_start();

// Memanggil file config.php untuk menghubungkan ke database
require_once 'config.php';

// Query untuk mengambil data ruangan dari database
$query = "SELECT * FROM ruangan";
$result = $conn->query($query);

// Query untuk mengambil data jadwal dari database
$query_jadwal = "
    SELECT jr.*, r.nama_ruangan 
    FROM jadwal_ruangan jr
    JOIN ruangan r ON jr.id_ruangan = r.id_ruangan
    ORDER BY jr.tanggal, jr.waktu_mulai";
// Eksekusi query jadwal dan simpan hasilnya ke variabel $result_jadwal
$result_jadwal = $conn->query($query_jadwal);

// Inisialisasi array untuk menyimpan data ruangan
$ruangan = array();

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $ruangan[] = $row;
    }
}

// Query untuk mengambil data user dari database berdasarkan username
$query_user = "SELECT * FROM registrations WHERE username = '$username'";
$result_user = $conn->query($query_user);

// Inisialisasi variabel untuk menyimpan data user
$user = null;

if ($result_user && $result_user->num_rows > 0) {
    $user = $result_user->fetch_assoc();
}
?>

<!doctype html>
<html lang="en">

<head>
    <title>Electromagnetic Door Locks</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,700' rel='stylesheet' type='text/css'>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="css/style.css">


    <script>
        function toggleSidebar() {
            var sidebar = document.querySelector('.sidebar');
            var hamburger = document.querySelector('.hamburger');

            sidebar.classList.toggle('open');
            hamburger.classList.toggle('open');
        }
    </script>
    <style>
        /* Tata letak dan gaya umum */
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #e6f7ff;
            /* Warna latar belakang yang lebih cerah */
            color: #004d80;
            /* Warna teks yang lebih cerah */
        }

        /* Gaya untuk header */
        .heading-section {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 1rem;
            color: #007acc;
            /* Warna header yang lebih cerah */
        }

        /* Sidebar */
        .sidebar {
            position: absolute;
            left: 0;
            top: 0;
            height: 100%;
            width: 250px;
            background: #007acc;
            /* Warna sidebar yang lebih cerah */
            padding: 15px;
            display: none;
            /* Default tidak tampil */
        }

        .sidebar.open {
            display: block;
            /* Tampil saat open class ditambahkan */
        }

        .sidebar h3 {
            color: #ffffff;
            text-align: center;
            margin-bottom: 20px;
        }

        .sidebar .dropdown-item {
            display: flex;
            align-items: center;
            padding: 10px 15px;
            color: #ffffff;
            text-decoration: none;
            border-bottom: 1px solid #005b99;
            /* Warna pembatas yang lebih cerah */
        }

        .sidebar .dropdown-item i {
            margin-right: 10px;
            /* Spasi antara ikon dan teks */
        }

        .sidebar .dropdown-item:hover {
            background-color: #005b99;
            /* Warna hover yang lebih cerah */
        }

        /* Gaya untuk tabel */
        .table-wrap {
            margin-top: 20px;
            overflow-x: auto;
        }

        .table-wrap table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            background-color: #ffffff;
            border: 1px solid #b3e0ff;
            /* Warna border tabel yang lebih cerah */
            border-radius: 5px;
        }

        .table-wrap th,
        .table-wrap td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #b3e0ff;
            /* Warna border bawah sel tabel yang lebih cerah */
        }

        .table-wrap th {
            background-color: #007acc;
            /* Warna header tabel yang lebih cerah */
            color: #ffffff;
        }

        .table-wrap td {
            background-color: #e6f7ff;
            /* Warna latar belakang sel tabel yang lebih cerah */
        }

        .table-wrap tr:hover td {
            background-color: #cceeff;
            /* Warna hover sel tabel yang lebih cerah */
        }

        .profile {
            margin-top: 10px;
            text-align: center;
        }

        /* Gaya untuk hamburger menu */
        .hamburger {
            cursor: pointer;
            margin-top: 20px;
        }

        .hamburger span {
            display: block;
            width: 30px;
            height: 3px;
            margin-bottom: 5px;
            background-color: #007acc;
            /* Warna hamburger menu yang lebih cerah */
            transition: all 0.3s ease;
        }

        .hamburger.open span:nth-child(1) {
            transform: rotate(45deg);
            position: relative;
            top: 7px;
        }

        .hamburger.open span:nth-child(2) {
            opacity: 0;
        }

        .hamburger.open span:nth-child(3) {
            transform: rotate(-45deg);
            position: relative;
            top: -7px;
        }
    </style>
</head>

<body>
    <section class="ftco-section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-6 text-center mb-5">
                    <h1 class="heading-section">Daftar Ruangan</h1>
                    <p class="welcome">Welcome</p>

                    <div class="hamburger" onclick="toggleSidebar()">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </div>
                <div class="sidebar">
                    <h3>Menu Dashboard</h3>
                    <div class="dropdown">

                    </div>
                    <a href="pesanan_diterima.php" class="dropdown-item">List Ruangan</a>
                    <?php if (isset($_SESSION['username'])) { ?>
                        <a href="ruangan.php" class="dropdown-item">Daftar Ruangan</a>
                        <a href="booking.php" class="dropdown-item">Request Ruangan</a>
                    <?php } ?>
                </div>
                <div class="">
                    <?php
                    if (isset($_SESSION['username'])) {
                        echo "<a href='logout.php' class='btn btn-danger'>Keluar</a>";
                    } else {
                        echo "<a href='login.php' class='btn btn-primary'>Masuk</a>";
                    }
                    ?>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="table-wrap">
                        <?php
                        if ($result_jadwal && $result_jadwal->num_rows > 0) {
                            echo "<table>";
                            echo "<thead>";
                            echo "<tr>";
                            echo "<th>Ruangan</th>";
                            echo "<th>Tanggal</th>";
                            echo "<th>Waktu Mulai</th>";
                            echo "<th>Waktu Selesai</th>";
                            echo "<th>Keterangan</th>";
                            echo "</tr>";
                            echo "</thead>";
                            echo "<tbody>";

                            // Output data of each row
                            while ($row = $result_jadwal->fetch_assoc()) {
                                echo "<tr>";
                                echo "<td>" . htmlspecialchars($row["nama_ruangan"]) . "</td>";
                                echo "<td>" . htmlspecialchars($row["tanggal"]) . "</td>";
                                echo "<td>" . htmlspecialchars($row["waktu_mulai"]) . "</td>";
                                echo "<td>" . htmlspecialchars($row["waktu_selesai"]) . "</td>";
                                echo "<td>" . htmlspecialchars($row["keterangan"]) . "</td>";
                                echo "</tr>";
                            }
                            echo "</tbody>";
                            echo "</table>";
                        } else {
                            echo "<p>Tidak ada jadwal ruangan yang tersedia.</p>";
                        }
                        $conn->close();
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>

</body>

</html>