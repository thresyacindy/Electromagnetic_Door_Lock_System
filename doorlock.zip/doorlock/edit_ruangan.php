<?php
// Konfigurasi koneksi ke database
require_once('config.php');

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$nama_ruangan = ''; // Inisialisasi variabel dengan nilai default
$ip_device = '';    // Inisialisasi variabel dengan nilai default

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_ruangan = $_POST['nama_ruangan'];
    $ip_device = $_POST['ip_device'];
    $sql = "UPDATE ruangan SET nama_ruangan=?, ip_device=? WHERE id_ruangan=?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("ssi", $nama_ruangan, $ip_device, $id);
        if ($stmt->execute()) {
            header("Location: ruangan2.php");
            exit();
        } else {
            echo "<p>Error: " . $stmt->error . "</p>";
        }
        $stmt->close();
    } else {
        echo "<p>Error preparing statement: " . $conn->error . "</p>";
    }
}

// Inisialisasi variabel default jika ID tidak valid
$id_ruangan = $id;

if ($id > 0) { // Pastikan ID valid sebelum melakukan query
    $sql = "SELECT nama_ruangan, ip_device FROM ruangan WHERE id_ruangan=?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->bind_result($nama_ruangan, $ip_device);
        if (!$stmt->fetch()) {
            // Data tidak ditemukan, arahkan kembali atau tampilkan pesan
            echo "<p>Ruangan dengan ID ini tidak ditemukan.</p>";
            exit;
        }
        $stmt->close();
    }
} else {
    // Jika ID tidak valid, arahkan kembali atau tampilkan pesan
    echo "<p>ID ruangan tidak valid.</p>";
    exit;
}

// Tutup koneksi database
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Ruangan</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 4px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .container h1 {
            margin-top: 0;
            text-align: center;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
        }

        .form-group input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .form-group input:focus {
            border-color: #007bff;
            outline: none;
        }

        .form-group button {
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            background-color: #007bff;
            color: white;
            cursor: pointer;
            font-size: 16px;
        }

        .form-group button:hover {
            background-color: #0056b3;
        }

        .form-group a {
            display: inline-block;
            margin-top: 10px;
            color: #007bff;
            text-decoration: none;
        }

        .form-group a:hover {
            text-decoration: underline;
        }

        .error-message {
            color: red;
            text-align: center;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Edit Ruangan</h1>
        <?php if (isset($success)): ?>
            <p class="success-message"><?php echo $success; ?></p>
        <?php elseif (isset($error)): ?>
            <p class="error-message"><?php echo $error; ?></p>
        <?php endif; ?>
        <form method="post">
            <div class="form-group">
                <label for="nama_ruangan">Nama Ruangan:</label>
                <input type="text" id="nama_ruangan" name="nama_ruangan" value="<?php echo htmlspecialchars($nama_ruangan); ?>" required>
            </div>
            <div class="form-group">
                <label for="ip_device">IP Device:</label>
                <input type="text" id="ip_device" name="ip_device" value="<?php echo htmlspecialchars($ip_device); ?>" required>
            </div>
            <div class="form-group">
                <button type="submit">Simpan</button>
                <a href="ruangan2.php">Kembali</a>
            </div>
        </form>
    </div>
</body>
</html>
