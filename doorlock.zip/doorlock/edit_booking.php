<?php
// Konfigurasi koneksi ke database
require_once('config.php');

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id'])) {
    // Ambil ID dari form
    $id = $_POST['id'];

    // Lakukan operasi edit data sesuai kebutuhan
    // Contoh: Redirect ke halaman edit dengan membawa ID sebagai parameter
    header("Location: edit_page.php?id=$id");
    exit();
} else {
    // Jika tidak ada ID yang diterima, kembalikan pengguna ke halaman sebelumnya
    header("Location: index.php");
    exit();
}
?>
