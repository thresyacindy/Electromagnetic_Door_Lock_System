<!DOCTYPE html>
<html>
<head>
    <title>Unauthorized</title>
</head>
<body>
    <h1>Unauthorized Access</h1>
    <p>Anda tidak diizinkan mengakses halaman ini.</p>
    <a href="login.php">Kembali ke Halaman Login</a>
</body>
</html>
