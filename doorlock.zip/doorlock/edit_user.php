<?php
session_start();

// Koneksi ke database (sesuaikan dengan informasi koneksi Anda)
require_once('config.php');

// Cek apakah ID pengguna sudah diterima melalui URL
if (isset($_GET['id'])) {
    $userId = $_GET['id'];

    // Ambil data pengguna berdasarkan ID
    $query = "SELECT * FROM registrations WHERE id = '$userId'";
    $result = mysqli_query($conn, $query);
    $user = mysqli_fetch_assoc($result);

    // Cek apakah form telah disubmit
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $role = $_POST['role'];

        // Update data pengguna
        $updateQuery = "UPDATE registrations SET username = '$username', email = '$email', role = '$role' WHERE id = '$userId'";
        $updateResult = mysqli_query($conn, $updateQuery);

        if ($updateResult) {
            $success = 'Data pengguna berhasil diperbarui!';
        } else {
            $error = 'Terjadi kesalahan saat memperbarui data pengguna.';
        }
    }
} else {
    header("Location: user_list.php"); // Redirect jika ID tidak ada
    exit;
}

// Tutup koneksi database
mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Pengguna</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<style>
    body {
    font-family: Arial, sans-serif;
    background-color: #f8f9fa;
    margin: 0;
    padding: 20px;
}

.container {
    max-width: 600px;
    margin: 50px auto;
    background-color: #ffffff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
}

h1 {
    text-align: center;
    margin-bottom: 30px;
    color: #343a40;
}

.alert {
    margin-top: 20px;
    padding: 15px;
    border-radius: 4px;
    text-align: center;
}

.alert-success {
    color: #155724;
    background-color: #d4edda;
    border: 1px solid #c3e6cb;
}

.alert-danger {
    color: #721c24;
    background-color: #f8d7da;
    border: 1px solid #f5c6cb;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    font-weight: bold;
    color: #495057;
}

.form-control {
    border-radius: 4px;
    border: 1px solid #ced4da;
    padding: 10px;
    width: 100%;
    box-sizing: border-box;
    font-size: 16px;
    color: #495057;
}

.form-control:focus {
    border-color: #007bff;
    box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
}

.btn-primary {
    background-color: #007bff;
    border-color: #007bff;
    padding: 10px 20px;
    font-size: 16px;
    border-radius: 4px;
    transition: background-color 0.3s, box-shadow 0.3s;
}

.btn-primary:hover {
    background-color: #0056b3;
}

.btn-secondary {
    background-color: #6c757d;
    border-color: #6c757d;
    padding: 10px 20px;
    font-size: 16px;
    border-radius: 4px;
    transition: background-color 0.3s, box-shadow 0.3s;
}

.btn-secondary:hover {
    background-color: #5a6268;
}

@media (max-width: 576px) {
    .container {
        margin: 20px auto;
        padding: 15px;
    }

    h1 {
        font-size: 24px;
        margin-bottom: 20px;
    }

    .btn {
        width: 100%;
        margin-bottom: 10px;
    }
}
</style>
<body>
    <div class="container">
        <h1>Edit Pengguna</h1>
        <?php if (isset($success)): ?>
            <p class="alert alert-success"><?php echo $success; ?></p>
        <?php elseif (isset($error)): ?>
            <p class="alert alert-danger"><?php echo $error; ?></p>
        <?php endif; ?>
        <form method="POST" action="">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" class="form-control" id="username" name="username" value="<?php echo $user['username']; ?>" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" class="form-control" id="email" name="email" value="<?php echo $user['email']; ?>" required>
            </div>
            <div class="form-group">
                <label for="role">Role:</label>
                <select class="form-control" id="role" name="role" required>
                    <option value="admin" <?php echo ($user['role'] === 'admin') ? 'selected' : ''; ?>>Admin</option>
                    <option value="pengelola" <?php echo ($user['role'] === 'pengelola') ? 'selected' : ''; ?>>Pengelola</option>
                    <option value="user" <?php echo ($user['role'] === 'user') ? 'selected' : ''; ?>>User</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
            <a href="approve.php" class="btn btn-secondary">Kembali</a>
        </form>
    </div>
</body>
</html>
