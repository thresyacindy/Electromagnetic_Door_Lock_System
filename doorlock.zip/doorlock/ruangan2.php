<?php
// Konfigurasi koneksi ke database
require_once('config.php');

// Fungsi untuk mengambil data ruangan dari tabel "ruangan"
function getRuanganData($conn) {
    $sql = "SELECT id_ruangan, nama_ruangan, ip_device FROM ruangan";
    $result = $conn->query($sql);
    return $result;
}

// Menampilkan data ruangan
function displayRuanganData($result) {
    if ($result->num_rows > 0) {
        echo "<table>";
        echo "<tr>
        <th>ID Ruangan</th>
        <th>Nama Ruangan</th>
        <th>IP Device</th>
        <th>Aksi</th>
        </tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row["id_ruangan"] . "</td>";
            echo "<td>" . $row["nama_ruangan"] . "</td>";
            echo "<td>" . $row["ip_device"] . "</td>";
            echo "<td>
            <a href='edit_ruangan.php?id=" . $row["id_ruangan"] . "' class='btn btn-primary btn-edit'>Edit</a>
            <a href='delete_ruangan.php?id=" . $row["id_ruangan"] . "' class='btn btn-danger btn-delete' onclick='return confirm(\"Apakah Anda yakin ingin menghapus ruangan ini?\")'>Hapus</a>
        </td>";        
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>Tidak ada ruangan yang tersedia.</p>";
    }
}

// Fungsi untuk menambahkan data ruangan
function tambahRuangan($conn, $nama_ruangan, $ip_device) {
    $sql = "INSERT INTO ruangan (nama_ruangan, ip_device) VALUES ('$nama_ruangan', '$ip_device')";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Ruangan berhasil ditambahkan');</script>";
    } else {
        echo "<script>alert('Error: " . $sql . "<br>" . $conn->error . "');</script>";
    }
}

// Fungsi untuk mengedit data ruangan
function editRuangan($conn, $id_ruangan, $nama_ruangan, $ip_device) {
    $sql = "UPDATE ruangan SET nama_ruangan='$nama_ruangan', ip_device='$ip_device' WHERE id_ruangan='$id_ruangan'";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Ruangan berhasil diperbarui');</script>";
    } else {
        echo "<script>alert('Error: " . $sql . "<br>" . $conn->error . "');</script>";
    }
}

// Fungsi untuk menghapus data ruangan
function hapusRuangan($conn, $id_ruangan) {
    $sql = "DELETE FROM ruangan WHERE id_ruangan='$id_ruangan'";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Ruangan berhasil dihapus');</script>";
    } else {
        echo "<script>alert('Error: " . $sql . "<br>" . $conn->error . "');</script>";
    }
}

// Fungsi untuk mengirim permintaan HTTP ke Arduino dan mengembalikan respons
function sendRequestToArduino($url)
{
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
    return $response;
}

// Memeriksa metode HTTP yang digunakan
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['tambahRuangan'])) {
        $nama_ruangan = $_POST['nama_ruangan'];
        $ip_device = $_POST['ip_device'];
        tambahRuangan($conn, $nama_ruangan, $ip_device);
    }

    if (isset($_POST['editRuangan'])) {
        $id_ruangan = $_POST['id_ruangan'];
        $nama_ruangan = $_POST['nama_ruangan'];
        $ip_device = $_POST['ip_device'];
        editRuangan($conn, $id_ruangan, $nama_ruangan, $ip_device);
    }

    if (isset($_POST['hapusRuangan'])) {
        $id_ruangan = $_POST['hapusRuangan'];
        hapusRuangan($conn, $id_ruangan);
    }

    if (isset($_POST['toggleDoor1'])) {
        $status = $_POST['toggleDoor1'];
        $url = 'http://' . $arduinoIP1 . '/3/' . $status;
        $response = sendRequestToArduino($url);
        echo "<script>alert('Ruang Telah " . ($status == 'on' ? 'BUKA' : 'TUTUP') . "');</script>";
    }

    if (isset($_POST['toggleDoor2'])) {
        $status = $_POST['toggleDoor2'];
        $url = 'http://' . $arduinoIP2 . '/3/' . $status;
        $response = sendRequestToArduino($url);
        echo "<script>alert('Ruang Telah " . ($status == 'on' ? 'BUKA' : 'TUTUP') . "');</script>";
    }
}

// Menampilkan data ruangan
$result = getRuanganData($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tampilan Ruangan</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
body {
    font-family: Arial, sans-serif;
    background-color: #f5f5f5;
    margin: 0;
    padding: 20px;
}

.container {
    max-width: 100%;
    margin: 0 auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.container h2 {
    margin-top: 0;
    text-align: center;
    color: #333;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
    border-radius: 8px;
    overflow: hidden;
}

table th, table td {
    padding: 16px;
    text-align: left;
    border-bottom: 1px solid #ddd;
    vertical-align: middle;
}

table th {
    background-color: #007bff;
    color: white;
    font-weight: bold;
}

table tr:nth-child(even) {
    background-color: #f9f9f9;
}

table tr:hover {
    background-color: #f1f1f1;
}

.dashboard-btn-container {
    margin-top: 20px;
    text-align: center;
}

.dashboard-btn {
    background-color: #4caf50;
    color: white;
    border: none;
    padding: 12px 24px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    border-radius: 4px;
    cursor: pointer;
    margin-right: 10px;
    transition: background-color 0.3s ease;
}

.dashboard-btn:hover {
    background-color: #45a049;
}

.action-btn {
    padding: 8px 16px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 14px;
    border-radius: 4px;
    cursor: pointer;
    margin-right: 8px;
    transition: background-color 0.3s ease;
}

.action-btn i {
    margin-right: 5px;
}

.btn-view-detail {
    background-color: #007bff;
    color: white;
}

.btn-print {
    background-color: #17a2b8;
    color: white;
}

.action-btn:hover {
    background-color: #0056b3;
    opacity: 0.9;
}

@media (max-width: 768px) {
    table th, table td {
        padding: 12px;
        font-size: 14px;
    }

    .dashboard-btn, .action-btn {
        padding: 10px 20px;
        font-size: 14px;
    }
}

    </style>
</head>
<body>
    <div class="container">
        <h2>Tampilan Ruangan</h2>
        <?php displayRuanganData($result); ?>

        <div class="dashboard-btn-container">
            <button class="dashboard-btn" onclick="window.location.href = 'tambah_ruangan.php';">Tambah Ruangan</button>    
            <button class="dashboard-btn" onclick="window.location.href = 'index1.php';">Kembali ke Dashboard</button>
        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
