<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "doorlock";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get QR code data from POST request
$id_booking = $_POST['id_booking'];
$id_ruangan = $_POST['id_ruangan'];
$timestamp = $_POST['timestamp'];

// Validate the data
$sql = "SELECT * FROM bookings WHERE id_booking = ? AND id_ruangan = ? AND ? BETWEEN waktu_mulai AND waktu_selesai";
$stmt = $conn->prepare($sql);
$stmt->bind_param("iis", $id_booking, $id_ruangan, $timestamp);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo "valid";
} else {
    echo "invalid";
}

$stmt->close();
$conn->close();
?>

