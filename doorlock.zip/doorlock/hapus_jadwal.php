<?php
require_once('config.php');

if (isset($_GET['id_jadwal'])) {
    $id_jadwal = $_GET['id_jadwal'];

    // Hapus jadwal dari database
    $sql = "DELETE FROM jadwal_ruangan WHERE id_jadwal = ?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $id_jadwal);
        if ($stmt->execute()) {
            echo "<script>alert('Jadwal berhasil dihapus.'); window.location.href='jadwal_ruangan.php';</script>";
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    }
} else {
    echo "<script>alert('ID Jadwal tidak ditemukan.'); window.location.href='jadwal_ruangan.php';</script>";
}

$conn->close();
?>
