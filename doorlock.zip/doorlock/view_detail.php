<?php //memulai blok kode php
// Pastikan ID booking diterima dari parameter URL
if(isset($_GET['id']) && !empty($_GET['id'])) { ///Memeriksa apakah parameter id dikirim melalui URL (menggunakan metode GET) dan memastikan bahwa nilainya tidak kosong
    // Konfigurasi koneksi ke database
    require_once('config.php'); //konfigurasi untuk database 

    // Escape string untuk mencegah serangan SQL injection
    $booking_id = mysqli_real_escape_string($conn, $_GET['id']); //Mengamankan nilai id dari input pengguna

    // Query untuk mendapatkan detail booking berdasarkan ID
    $sql = "SELECT * FROM bookings WHERE id = '$booking_id'";
    $result = $conn->query($sql); //menjalankan dan menyimpan query

    // Jika data ditemukan
    if ($result->num_rows > 0) { //memeriksa data 
        $row = $result->fetch_assoc(); //mengambil data query
        ?>
        <!DOCTYPE html> 
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Detail Booking</title>
            <!-- Include Font Awesome CSS -->
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
            <style>
                body {
                    font-family: Arial, sans-serif;
                    background-color: #f5f5f5;
                    margin: 0;
                    padding: 20px;
                }
                .container {
                    max-width: 600px;
                    margin: 0 auto;
                    background-color: #fff;
                    padding: 20px;
                    border-radius: 4px;
                    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
                }
                .container h2 {
                    margin-top: 0;
                    text-align: center;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                    margin-top: 20px;
                }
                table th, table td {
                    padding: 12px 16px;
                    text-align: left;
                    border-bottom: 1px solid #ddd;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <h2>Detail Booking</h2>
                <table>
                    <tr>
                        <th>ID</th>
                        <td><?php echo $row["id"]; ?></td> <!-- menampilkan data dari setiap kolom tabel booking-->
                    </tr>
                    <tr>
                        <th>Nama</th>
                        <td><?php echo $row["nama"]; ?></td>
                    </tr>
                    <tr>
                        <th>Email</th>
                        <td><?php echo $row["email"]; ?></td>
                    </tr>
                    <tr>
                        <th>Tanggal Booking</th>
                        <td><?php echo $row["tanggal_booking"]; ?></td>
                    </tr>
                    <tr>
                        <th>Waktu Mulai</th>
                        <td><?php echo $row["waktu_mulai"]; ?></td>
                    </tr>
                    <tr>
                        <th>Waktu Selesai</th>
                        <td><?php echo $row["waktu_selesai"]; ?></td>
                    </tr>
                    <tr>
                        <th>Ruangan</th>
                        <td><?php echo $row["ruangan"]; ?></td>
                    </tr>
                    <tr>
                        <th>Catatan Tambahan</th>
                        <td><?php echo $row["catatan_tambahan"]; ?></td>
                    </tr>
                    <tr>
                        <th>Created At</th>
                        <td><?php echo $row["created_at"]; ?></td>
                    </tr>
                </table>
            </div>
        </body>
        </html>
        <?php
    } else {
        echo "Data booking tidak ditemukan.";
    }

    // Tutup koneksi ke database
    $conn->close();
} else {
    echo "ID booking tidak ditemukan.";
}
?>
