<?php
session_start();

// Koneksi ke database (sesuaikan dengan informasi koneksi Anda)
require_once('config.php');

if (isset($_GET['id'])) {
    $userId = $_GET['id'];

    // Hapus data pengguna berdasarkan ID
    $query = "DELETE FROM registrations WHERE id = '$userId'";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $success = 'Pengguna berhasil dihapus!';
    } else {
        $error = 'Terjadi kesalahan saat menghapus pengguna.';
    }
} else {
    header("Location: user_list.php"); // Redirect jika ID tidak ada
    exit;
}

mysqli_close($conn);

// Redirect kembali ke halaman daftar pengguna dengan pesan sukses atau error
header("Location: user_list.php?success=" . urlencode($success) . "&error=" . urlencode($error));
exit;
