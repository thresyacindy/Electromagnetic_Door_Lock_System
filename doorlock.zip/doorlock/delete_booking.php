<?php
// Konfigurasi koneksi ke database
require_once('config.php');

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id'])) {
    // Ambil ID dari form
    $id = $_POST['id'];

    // Lakukan operasi hapus data sesuai kebutuhan
    // Contoh: Hapus data dari tabel berdasarkan ID
    $sql = "DELETE FROM bookings WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        // Jika penghapusan berhasil, kembalikan pengguna ke halaman sebelumnya
        header("Location: index2.php");
        exit();
    } else {
        // Jika terjadi kesalahan, tampilkan pesan kesalahan atau tangani sesuai kebutuhan
        echo "Error: " . $conn->error;
    }
} else {
    // Jika tidak ada ID yang diterima, kembalikan pengguna ke halaman sebelumnya
    header("Location: index2.php");
    exit();
}

// Tutup koneksi database
$conn->close();
?>
