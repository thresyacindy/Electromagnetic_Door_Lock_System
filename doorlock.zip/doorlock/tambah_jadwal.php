<!DOCTYPE html>
<html>
<head>
    <title>Tambah Jadwal Ruangan</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <h2>Tambah Jadwal Ruangan</h2>
        <form method="post" action="proses_tambah_jadwal.php">
            <div class="form-group">
                <label for="id_ruangan">Nama Ruangan:</label>
                <select name="id_ruangan" id="id_ruangan" class="form-control" required>
                    <?php
                    // Ambil data ruangan
                    require_once('config.php');
                    $sql = "SELECT id_ruangan, nama_ruangan FROM ruangan";
                    $result = $conn->query($sql);
                    while ($row = $result->fetch_assoc()) {
                        echo "<option value='" . $row["id_ruangan"] . "'>" . $row["nama_ruangan"] . "</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="tanggal">Tanggal:</label>
                <input type="date" name="tanggal" id="tanggal" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="waktu_mulai">Waktu Mulai:</label>
                <input type="time" name="waktu_mulai" id="waktu_mulai" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="waktu_selesai">Waktu Selesai:</label>
                <input type="time" name="waktu_selesai" id="waktu_selesai" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="keterangan">Keterangan:</label>
                <textarea name="keterangan" id="keterangan" class="form-control"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Tambah Jadwal</button>
        </form>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
