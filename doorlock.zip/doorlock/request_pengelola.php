<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Pemesanan</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="styles.css"> <!-- Letakkan CSS tambahan Anda di sini -->
    <style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }
        .no-booking-message {
            font-style: italic;
            color: #888;
        }
        .button-container {
            text-align: center;
        }
        .dashboard-link {
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php 
            // Konfigurasi koneksi ke database
            require_once('config.php');

            // Mengambil data pemesanan dari tabel "booking"
            $sql = "SELECT * FROM bookings";
            $result = $conn->query($sql);
        ?>

        <?php if ($result->num_rows > 0) : ?>
            <h2 class="mb-4">Daftar Pemesanan</h2>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Tanggal Booking</th>
                            <th>Waktu Mulai</th>
                            <th>Waktu Selesai</th>
                            <th>Ruangan</th>
                            <th>Catatan Tambahan</th>
                            <th>Dibuat Pada</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()) : ?>
                            <tr>
                                <td><?= $row["id"] ?></td>
                                <td><?= $row["nama"] ?></td>
                                <td><?= $row["email"] ?></td>
                                <td><?= $row["tanggal_booking"] ?></td>
                                <td><?= $row["waktu_mulai"] ?></td>
                                <td><?= $row["waktu_selesai"] ?></td>
                                <td><?= $row["ruangan"] ?></td>
                                <td><?= $row["catatan_tambahan"] ?></td>
                                <td><?= $row["created_at"] ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else : ?>
            <p class="no-booking-message">Belum ada data pemesanan.</p>
        <?php endif; ?>
    </div>

    <div class="button-container mt-4">
        <a href="index2.php" class="dashboard-link">
            <button class="btn btn-primary">Kembali ke Dashboard</button>
        </a>
    </div>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
