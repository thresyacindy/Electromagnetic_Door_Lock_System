<?php
session_start();
require_once('config.php');

// Fungsi untuk memeriksa keberadaan username dalam database
function usernameExists($conn, $username)
{
    $query = "SELECT * FROM registrations WHERE username = ? AND status = 'approved'";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $registration = mysqli_fetch_assoc($result);

    return $registration;
}

// Proses login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Periksa apakah username dan password cocok dalam database yang sudah disetujui
    $registration = usernameExists($conn, $username);
    if ($registration) {
        if (password_verify($password, $registration['password'])) {
            $_SESSION['role'] = $registration['role'];

            // get data user from database
            $user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM registrations WHERE username = '$username'"));

            // set session
            $_SESSION['id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['name'] = $user['name'];

            // set cookie
            setcookie('username', $username, time() + (86400 * 30), "/");

            // Alihkan pengguna ke halaman dashboard sesuai peran
            switch ($registration['role']) {
                case 'admin':
                    header('Location: index1.php');
                    break;
                case 'pengelola':
                    header('Location: index2.php');
                    break;
                case 'user':
                    header('Location: index.php');
                    break;
                default:
                    $error = 'Peran pengguna tidak valid!';
            }
            exit();
        } else {
            $error = 'Password salah!';
        }
    } else {
        $error = 'Username tidak valid atau belum disetujui!';
    }
}

// Tutup koneksi database
mysqli_close($conn);
?>

<!DOCTYPE html>
<html>

<head>
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            width: 400px;
            background-color: #fff;
            border-radius: 5px;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .container img {
            width: 100px;
            /* Sesuaikan ukuran gambar */
            height: auto;
            margin-bottom: 20px;
        }

        .container h1 {
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 15px;
            text-align: left;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-group input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        .form-group input[type="submit"] {
            background-color: #0000FF;
            color: #fff;
            cursor: pointer;
        }

        .form-group input[type="submit"]:hover {
            background-color: #000080;
        }

        .form-group .register-link {
            display: block;
            margin-top: 10px;
            text-align: center;
        }

        .form-group .register-link a {
            color: #337ab7;
            text-decoration: none;
        }

        .error-message {
            color: red;
            text-align: center;
            margin-bottom: 15px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Log in</h1>
        <?php if (isset($error)): ?>
            <p class="error-message"><?php echo $error; ?></p>
        <?php endif; ?>
        <form method="POST" action="">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" name="username" id="username" required>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" id="password" required>
            </div>

            <div class="form-group">
                <input type="submit" value="Login">
            </div>
        </form>
        <div class="form-group">
            <p class="register-link">Belum memiliki akun? <a href="registrasi.php">Registrasi</a></p>
        </div>
    </div>
</body>

</html>