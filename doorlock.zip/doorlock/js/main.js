(function($) {

	"use strict";

})(jQuery);


