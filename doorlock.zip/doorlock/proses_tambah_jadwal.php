<?php
// Konfigurasi koneksi ke database
require_once('config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') { //digunakan untuk memeriksa metode HTTP 
    $id_ruangan = intval($_POST['id_ruangan']); //intval() digunakan pada id_ruangan untuk mengonversi nilai yang diinput menjadi integer, memastikan bahwa input adalah angka
    $tanggal = $_POST['tanggal'];
    $waktu_mulai = $_POST['waktu_mulai'];
    $waktu_selesai = $_POST['waktu_selesai'];
    $keterangan = $_POST['keterangan'];

    $sql = "INSERT INTO jadwal_ruangan (id_ruangan, tanggal, waktu_mulai, waktu_selesai, keterangan) 
            VALUES (?, ?, ?, ?, ?)";

    if ($stmt = $conn->prepare($sql)) { //memeriksa apakah persiapan query berhasil. 
        $stmt->bind_param("issss", $id_ruangan, $tanggal, $waktu_mulai, $waktu_selesai, $keterangan);
        if ($stmt->execute()) {
            header("Location: daftar_jadwal.php");
            exit();
        } else {
            echo "<p>Error: " . $stmt->error . "</p>";
        }
        $stmt->close();
    } else {
        echo "<p>Error preparing statement: " . $conn->error . "</p>";
    }
}
?>
