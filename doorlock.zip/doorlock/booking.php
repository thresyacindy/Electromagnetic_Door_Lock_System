<?php
session_start();
// Konfigurasi koneksi ke database
require_once('config.php');

// Cek apakah tombol submit ditekan
if (isset($_POST['submit'])) {
    // Mengambil nilai dari form pemesanan ruangan
    $tanggalBooking = $_POST['tanggalBooking'];
    $waktuMulai = $_POST['waktuMulai'];
    $waktuSelesai = $_POST['waktuSelesai'];
    $ruangan = $_POST['ruangan'];
    $catatanTambahan = $_POST['catatanTambahan'];

    // Menghitung waktu kedaluwarsa
    $expiration_date = date("Y-m-d H:i:s", strtotime("$tanggalBooking $waktuSelesai"));

    // get user id
    $user_id = $_SESSION['id'];

    // get name and email
    $nama = $_SESSION['name'];
    $email = $_SESSION['email'];

    // Menyiapkan pernyataan SQL untuk menyimpan data pemesanan ruangan
    $sql = "INSERT INTO bookings (nama, email, tanggal_booking, waktu_mulai, waktu_selesai, ruangan, catatan_tambahan, created_at, status, expiration_date, id_user)
            VALUES ('$nama', '$email', '$tanggalBooking', '$waktuMulai', '$waktuSelesai', '$ruangan', '$catatanTambahan', NOW(), 'Menunggu', '$expiration_date', '$user_id')";

    if ($conn->query($sql) === TRUE) {
        $message = "Pemesanan ruangan berhasil disimpan.";
        echo "<script>alert('$message');</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Pemesanan Ruangan</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(to right, #f5f5f5, #ffffff);
            margin: 0;
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        form {
            max-width: 500px;
            margin: 0 auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border: 1px solid #ddd;
        }

        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
            color: #333;
        }

        input[type="text"],
        input[type="email"],
        input[type="date"],
        input[type="time"],
        textarea,
        select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-sizing: border-box;
            font-size: 16px;
            margin-bottom: 20px;
            transition: border-color 0.3s ease;
        }

        input[type="text"]:focus,
        input[type="email"]:focus,
        input[type="date"]:focus,
        input[type="time"]:focus,
        textarea:focus,
        select:focus {
            border-color: #4caf50;
            outline: none;
        }

        textarea {
            resize: vertical;
            min-height: 100px;
        }

        input[type="submit"],
        .dashboard-btn {
            background-color: #4caf50;
            color: #fff;
            border: none;
            padding: 15px 25px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 18px;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover,
        .dashboard-btn:hover {
            background-color: #45a049;
        }

        .dashboard-btn {
            background-color: #337ab7;
            margin-top: 20px;
        }

        .dashboard-btn-container {
            text-align: center;
        }

        .submit-container {
            text-align: center;
        }

        .select-container {
            position: relative;
        }

        .select-container::after {
            content: '\25BC';
            position: absolute;
            top: 50%;
            right: 12px;
            transform: translateY(-50%);
            pointer-events: none;
            color: #333;
        }
    </style>
</head>

<body>
    <h1>Form Pemesanan Ruangan</h1>
    <form method="POST" action="">
        <label for="nama">Nama:</label>
        <input type="text" name="nama" id="nama" value="<?php echo $_SESSION['name']; ?>" readonly>

        <label for="email">Email:</label>
        <input type="email" name="email" id="email" value="<?php echo $_SESSION['email']; ?>" readonly>

        <label for="tanggalBooking">Tanggal Booking:</label>
        <input type="date" name="tanggalBooking" id="tanggalBooking" required>

        <label for="waktuMulai">Waktu Mulai:</label>
        <input type="time" name="waktuMulai" id="waktuMulai" required>

        <label for="waktuSelesai">Waktu Selesai:</label>
        <input type="time" name="waktuSelesai" id="waktuSelesai" required>

        <label for="ruangan">Ruangan yang Dipilih:</label>
        <div class="select-container">
            <select name="ruangan" id="ruangan" required>
                <?php
                // Mengambil data ruangan dari tabel "ruangan"
                $sql = "SELECT * FROM ruangan";
                $result = $conn->query($sql);

                // Menampilkan opsi ruangan
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<option value='" . htmlspecialchars($row["nama_ruangan"]) . "'>" . htmlspecialchars($row["nama_ruangan"]) . "</option>";
                    }
                } else {
                    echo "<option value=''>Tidak ada ruangan tersedia</option>";
                }
                ?>
            </select>
        </div>

        <label for="catatanTambahan">Catatan Tambahan:</label>
        <textarea name="catatanTambahan" id="catatanTambahan"></textarea>

        <div class="submit-container">
            <input type="submit" name="submit" value="Submit">
        </div>

        <div class="dashboard-btn-container">
            <button class="dashboard-btn" onclick="window.location.href = 'ruangan.php';">Kembali ke Ruangan</button>
        </div>
    </form>
</body>

</html>

<?php
// Menutup koneksi database
$conn->close();
?>