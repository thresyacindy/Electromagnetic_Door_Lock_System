<?php
require_once('config.php');

// Ambil data dari QR Code yang dipindai
$data = json_decode(file_get_contents('php://input'), true);

// Validasi data dari QR Code
if (isset($data['id']) && isset($data['nama']) && isset($data['tanggal_booking']) && isset($data['waktu_mulai']) && isset($data['waktu_selesai']) && isset($data['ruangan']) && isset($data['expiration_date'])) {
    $id = $data['id'];
    $current_datetime = date('Y-m-d H:i:s');

    // Query untuk memeriksa data booking
    $sql = "SELECT * FROM bookings WHERE id = ? AND expiration_date >= ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $id, $current_datetime);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo json_encode(['status' => 'valid']);
    } else {
        echo json_encode(['status' => 'invalid']);
    }

    $stmt->close();
} else {
    echo json_encode(['status' => 'invalid']);
}

$conn->close();
?>