<?php
if (isset($_GET['id']) && !empty($_GET['id'])) {
    require_once('config.php');
    
    $booking_id = mysqli_real_escape_string($conn, $_GET['id']);
    
    // Query untuk mendapatkan detail booking berdasarkan ID
    $sql = "SELECT * FROM bookings WHERE id = '$booking_id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        
        // Data yang akan dimasukkan ke dalam QR code
        $data = json_encode([
            'id' => $row['id'],
            'nama' => $row['nama'],
            'email' => $row['email'],
            'tanggal_booking' => $row['tanggal_booking'],
            'waktu_mulai' => $row['waktu_mulai'],
            'waktu_selesai' => $row['waktu_selesai'],
            'ruangan' => $row['ruangan'],
            'expiration_date' => $row['expiration_date'],
        ]);

        // Encode data ke URL QR Code menggunakan API eksternal
        $qr_api_url = 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=' . urlencode($data);
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Print QR Code</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    background-color: #f5f5f5;
                    margin: 0;
                    padding: 20px;
                }
                .container {
                    max-width: 400px;
                    margin: 0 auto;
                    background-color: #fff;
                    padding: 20px;
                    border-radius: 4px;
                    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
                    text-align: center;
                }
                img {
                    max-width: 100%;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <h2>Print QR Code</h2>
                <p>QR Code untuk booking dengan ID <?php echo htmlspecialchars($row["id"]); ?> yang berlaku hingga <?php echo htmlspecialchars($row["expiration_date"]); ?></p>
                <img src="<?php echo htmlspecialchars($qr_api_url); ?>" alt="QR Code">
                <p><a href="#" onclick="window.print();">Print</a></p>
            </div>
        </body>
        </html>
        <?php
    } else {
        echo "Data booking tidak ditemukan.";
    }

    $conn->close();
} else {
    echo "ID booking tidak ditemukan.";
}
?>