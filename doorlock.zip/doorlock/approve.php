<?php
session_start();

// Koneksi ke database (sesuaikan dengan informasi koneksi Anda)
require_once('config.php');

// Fungsi untuk mendapatkan semua data registrasi pengguna
function getAllRegistrations($conn) {
    $query = "SELECT * FROM registrations";
    $result = mysqli_query($conn, $query);

    // Mengembalikan data registrasi dalam bentuk array asosiatif
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

// Fungsi untuk mengupdate status dan role registrasi
function updateRegistrationStatus($conn, $registrationId, $status, $role) {
    $query = "UPDATE registrations SET status = '$status', role = '$role' WHERE id = '$registrationId'";
    $result = mysqli_query($conn, $query);

    return $result;
}

// Mendapatkan semua data registrasi pengguna
$registrations = getAllRegistrations($conn);

// Memproses penolakan atau persetujuan registrasi jika ada permintaan dari form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $registrationId = $_POST['registrationId'];
    $action = $_POST['action'];
    $role = $_POST['role'];

    if ($action === 'approve') {
        $status = 'approved';
        $message = 'Registrasi berhasil disetujui!';
    } elseif ($action === 'reject') {
        $status = 'rejected';
        $message = 'Registrasi berhasil ditolak!';
    }

    // Update status dan role registrasi
    $result = updateRegistrationStatus($conn, $registrationId, $status, $role);

    if ($result) {
        $success = $message;
    } else {
        $error = 'Terjadi kesalahan. Gagal memperbarui status registrasi.';
    }
}

// Tutup koneksi database
mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Persetujuan Registrasi Pengguna</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f8f9fa;
    margin: 0;
    padding: 20px;
}

h1 {
    text-align: center;
    margin-bottom: 30px;
    color: #343a40;
}

.table {
    width: 100%;
    margin-top: 20px;
    background-color: #ffffff;
    border-collapse: separate;
    border-spacing: 0;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
    overflow: hidden;
}

.table th, .table td {
    padding: 16px;
    text-align: left;
    border-bottom: 1px solid #dee2e6;
}

.table th {
    background-color: #007bff;
    color: #ffffff;
    text-transform: uppercase;
    font-weight: bold;
}

.table td {
    color: #495057;
}

.table tbody tr:hover {
    background-color: #f1f3f5;
}

.success-message, .error-message {
    margin: 10px 0;
    padding: 12px;
    border-radius: 4px;
    text-align: center;
}

.success-message {
    color: #155724;
    background-color: #d4edda;
    border: 1px solid #c3e6cb;
}

.error-message {
    color: #721c24;
    background-color: #f8d7da;
    border: 1px solid #f5c6cb;
}

.form-inline {
    display: flex;
    align-items: center;
}

.form-inline select {
    margin-right: 10px;
}

.btn {
    padding: 8px 12px;
    font-size: 14px;
    border-radius: 4px;
}

.btn-success {
    background-color: #28a745;
    border-color: #28a745;
}

.btn-success:hover {
    background-color: #218838;
}

.btn-danger {
    background-color: #dc3545;
    border-color: #dc3545;
}

.btn-danger:hover {
    background-color: #c82333;
}

.btn-warning {
    background-color: #ffc107;
    border-color: #ffc107;
    color: #212529;
}

.btn-warning:hover {
    background-color: #e0a800;
}

.button-container {
    margin-top: 30px;
    text-align: center;
}

.dashboard-link button {
    background-color: #007bff;
    color: white;
    border: none;
    padding: 10px 20px;
    font-size: 16px;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s;
}

.dashboard-link button:hover {
    background-color: #0056b3;
}

@media (max-width: 768px) {
    .form-inline {
        flex-direction: column;
        align-items: flex-start;
    }

    .form-inline select,
    .form-inline button {
        width: 100%;
        margin-bottom: 10px;
    }

    .table th, .table td {
        padding: 12px;
    }
}
    </style>
</head>
<body>
    <h1>Persetujuan Registrasi Pengguna</h1>
    <?php if (isset($success)): ?>
        <p class="success-message"><?php echo $success; ?></p>
    <?php elseif (isset($error)): ?>
        <p class="error-message"><?php echo $error; ?></p>
    <?php endif; ?>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Role</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($registrations as $registration): ?>
            <tr>
                <td><?php echo $registration['id']; ?></td>
                <td><?php echo $registration['username']; ?></td>
                <td><?php echo $registration['email']; ?></td>
                <td><?php echo $registration['role']; ?></td>
                <td><?php echo $registration['status']; ?></td>
                <td>
                    <?php if ($registration['status'] === 'pending'): ?>
                        <form method="POST" action="" class="form-inline">
                            <input type="hidden" name="registrationId" value="<?php echo $registration['id']; ?>">
                            <select name="role" class="form-control mr-2" required>
                                <option value="admin">Admin</option>
                                <option value="pengelola">Pengelola</option>
                                <option value="user">User</option>
                            </select>
                            <button type="submit" name="action" value="approve" class="btn btn-success mr-2">Setujui</button>
                            <button type="submit" name="action" value="reject" class="btn btn-danger">Tolak</button>
                        </form>
                    <?php elseif ($registration['status'] === 'approved'): ?>
                        <a href="edit_user.php?id=<?php echo $registration['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                        <a href="delete_user.php?id=<?php echo $registration['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus pengguna ini?');">Hapus</a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <div class="button-container">
        <a href="index1.php" class="dashboard-link">
            <button class="btn btn-primary">Kembali ke Dashboard</button>
        </a>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
