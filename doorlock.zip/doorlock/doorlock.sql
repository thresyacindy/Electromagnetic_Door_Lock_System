-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 14, 2024 at 03:26 AM
-- Server version: 8.0.30
-- PHP Version: 8.2.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `doorlock`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int NOT NULL,
  `nama` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `tanggal_booking` date NOT NULL,
  `waktu_mulai` time NOT NULL,
  `waktu_selesai` time NOT NULL,
  `ruangan` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `catatan_tambahan` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('Disetujui','Ditolak','Menunggu') COLLATE utf8mb4_general_ci DEFAULT 'Menunggu',
  `expiration_date` datetime DEFAULT NULL,
  `id_ruangan` int DEFAULT NULL,
  `id_user` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `nama`, `email`, `tanggal_booking`, `waktu_mulai`, `waktu_selesai`, `ruangan`, `catatan_tambahan`, `created_at`, `status`, `expiration_date`, `id_ruangan`, `id_user`) VALUES
(1, 'Tasya Diva Aulia S', 'kelompokta@gmail.com', '2024-08-10', '17:31:00', '18:31:00', 'lab komputer', '', '2024-08-10 10:31:27', 'Disetujui', '2024-08-10 18:31:00', NULL, 0),
(2, 'Tasya Diva Aulia S', 'kelompokta@gmail.com', '2024-08-10', '17:47:00', '17:48:00', 'lab komputer', '', '2024-08-10 10:47:17', 'Disetujui', '2024-08-10 17:48:00', NULL, 0),
(3, 'Tasya Diva Aulia S', 'kelompokta@gmail.com', '2024-08-11', '15:06:00', '16:06:00', 'lab komputer', 'praktikum', '2024-08-11 08:07:40', 'Disetujui', '2024-08-11 16:06:00', NULL, 0),
(4, 'Tasya Diva Aulia S', 'kelompokta@gmail.com', '2024-08-11', '15:56:00', '15:56:00', 'Dantob', '', '2024-08-11 08:56:48', 'Disetujui', '2024-08-11 15:56:00', NULL, 0),
(5, 'Tasya Diva Aulia S', 'kelompokta@gmail.com', '2024-08-11', '20:13:00', '22:13:00', 'lab cisco', 'kolab', '2024-08-11 13:13:38', 'Disetujui', '2024-08-11 22:13:00', NULL, 0),
(6, 'Tasya Diva Aulia S', 'kelompokta@gmail.com', '2024-08-12', '08:44:00', '08:45:00', 'lab cisco', '', '2024-08-12 01:44:55', 'Disetujui', '2024-08-12 08:45:00', NULL, 0),
(7, 'Tasya Diva Aulia S', 'kelompokta@gmail.com', '2024-08-12', '09:27:00', '11:27:00', 'lab cisco', '', '2024-08-12 02:27:10', 'Disetujui', '2024-08-12 11:27:00', NULL, 0),
(8, 'Tasya Diva Aulia S', 'kelompokta@gmail.com', '2024-08-12', '10:00:00', '12:00:00', 'lab cisco', '', '2024-08-12 03:00:54', 'Disetujui', '2024-08-12 12:00:00', NULL, 0),
(9, 'Tasya Diva Aulia S', 'kelompokta@gmail.com', '2024-08-12', '10:01:00', '11:01:00', 'lab cisco', '', '2024-08-12 03:01:35', 'Disetujui', '2024-08-12 11:01:00', NULL, 0),
(10, 'Tasya Diva Aulia S', 'kelompokta@gmail.com', '2024-08-12', '15:31:00', '19:00:00', 'lab cisco', 'gabut', '2024-08-12 08:31:26', 'Disetujui', '2024-08-12 19:00:00', NULL, 0),
(11, 'Tasya Diva Aulia S', 'kelompokta@gmail.com', '2024-08-12', '16:23:00', '17:23:00', 'lab cisco', '', '2024-08-12 09:23:43', 'Disetujui', '2024-08-12 17:23:00', NULL, 0),
(12, 'Tasya Diva Aulia S', 'kelompokta@gmail.com', '2024-08-12', '18:15:00', '19:16:00', 'lab cisco', 'praktikum', '2024-08-12 11:15:13', 'Disetujui', '2024-08-12 19:16:00', NULL, 0),
(13, 'Tasya Diva Aulia S', 'kelompokta@gmail.com', '2024-08-12', '19:51:00', '21:51:00', 'lab cisco', 'kolab', '2024-08-12 12:51:38', 'Disetujui', '2024-08-12 21:51:00', NULL, 0),
(14, 'Tasya Diva Aulia S', 'kelompokta@gmail.com', '2024-08-12', '19:54:00', '21:57:00', 'lab cisco', 'kolab', '2024-08-12 12:55:08', 'Disetujui', '2024-08-12 21:57:00', NULL, 0),
(15, 'Tasya Diva Aulia S', 'kelompokta@gmail.com', '2024-08-13', '14:45:00', '15:45:00', 'lab cisco', '', '2024-08-13 07:45:38', 'Disetujui', '2024-08-13 15:45:00', NULL, 0),
(16, 'Tasya Diva Aulia S', 'kelompokta@gmail.com', '2024-08-13', '15:22:00', '17:22:00', 'lab cisco', 'presentation', '2024-08-13 08:22:35', 'Disetujui', '2024-08-13 17:22:00', NULL, 0),
(17, 'Tasya Diva Aulia S', 'kelompokta@gmail.com', '2024-08-12', '16:00:00', '17:00:00', 'lab cisco', '', '2024-08-13 09:00:03', 'Disetujui', '2024-08-12 17:00:00', NULL, 0),
(18, 'Tasya Diva Aulia S', 'kelompokta@gmail.com', '2024-08-13', '16:17:00', '17:17:00', 'RMK', '', '2024-08-13 09:18:06', 'Disetujui', '2024-08-13 17:17:00', NULL, 0),
(19, 'Tasya Diva Aulia S', 'kelompokta@gmail.com', '2024-08-13', '20:10:00', '20:10:00', 'lab cisco', '', '2024-08-13 13:10:43', 'Disetujui', '2024-08-13 20:10:00', NULL, 0),
(20, 'Tasya Diva Aulia S', 'kelompokta@gmail.com', '2024-08-13', '20:16:00', '20:16:00', 'lab cisco', '', '2024-08-13 13:16:25', 'Disetujui', '2024-08-13 20:16:00', NULL, 0),
(22, 'Tasya Diva Aulia S', 'kelompokta@gmail.com', '2024-08-13', '20:37:00', '22:37:00', 'RMK', '', '2024-08-13 13:37:57', 'Disetujui', '2024-08-13 22:37:00', NULL, 0),
(23, 'Tasya Diva Aulia S', 'kelompokta@gmail.com', '2024-08-13', '21:16:00', '22:16:00', 'RMK', '', '2024-08-13 14:16:44', 'Disetujui', '2024-08-13 22:16:00', NULL, 0),
(24, 'Tasya Diva Aulia S', 'kelompokta@gmail.com', '2024-08-13', '21:35:00', '23:35:00', 'RMK', '', '2024-08-13 14:35:24', 'Disetujui', '2024-08-13 23:35:00', NULL, 0),
(25, 'Tasya Diva Aulia S', 'kelompokta@gmail.com', '2024-08-14', '09:13:00', '13:13:00', 'lab cisco', '', '2024-08-14 02:13:45', 'Disetujui', '2024-08-14 13:13:00', NULL, 0),
(26, 'Tasya Diva Aulia S', 'kelompokta@gmail.com', '2024-08-14', '09:50:00', '11:50:00', 'RMK', '', '2024-08-14 02:50:29', 'Disetujui', '2024-08-14 11:50:00', NULL, 0),
(27, 'Tasya Diva Aulia S ', 'kelompokta@gmail.com', '2024-08-14', '09:52:00', '11:52:00', 'RMK', '', '2024-08-14 02:52:55', 'Disetujui', '2024-08-14 11:52:00', NULL, 0),
(28, 'Tasya Diva Aulia S', 'kelompokta@gmail.com', '2024-08-14', '09:56:00', '09:56:00', 'lab cisco', '', '2024-08-14 02:56:15', 'Disetujui', '2024-08-14 09:56:00', NULL, 0),
(29, 'Kelompok 2', 'kelompok2@gmail.com', '2024-08-14', '11:21:00', '01:21:00', 'lab cisco', '', '2024-08-14 03:22:03', 'Disetujui', '2024-08-14 01:21:00', NULL, 3),
(30, 'Tasya', 'tasyadiva@gmail.com', '2024-08-14', '10:22:00', '11:22:00', 'RMK', '', '2024-08-14 03:22:36', 'Menunggu', '2024-08-14 11:22:00', NULL, 4);

-- --------------------------------------------------------

--
-- Table structure for table `jadwal_ruangan`
--

CREATE TABLE `jadwal_ruangan` (
  `id_jadwal` int NOT NULL,
  `id_ruangan` int NOT NULL,
  `tanggal` date NOT NULL,
  `waktu_mulai` time NOT NULL,
  `waktu_selesai` time NOT NULL,
  `keterangan` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jadwal_ruangan`
--

INSERT INTO `jadwal_ruangan` (`id_jadwal`, `id_ruangan`, `tanggal`, `waktu_mulai`, `waktu_selesai`, `keterangan`) VALUES
(3, 514, '2024-08-07', '14:05:00', '17:08:00', 'tersedia'),
(4, 514, '2024-08-08', '03:00:00', '17:05:00', 'tersedia'),
(5, 514, '2024-08-12', '16:23:00', '17:24:00', 'tersedia');

-- --------------------------------------------------------

--
-- Table structure for table `registrations`
--

CREATE TABLE `registrations` (
  `id` int NOT NULL,
  `username` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `status` enum('pending','approved','rejected') COLLATE utf8mb4_general_ci NOT NULL,
  `role` enum('admin','pengelola','user') COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registrations`
--

INSERT INTO `registrations` (`id`, `username`, `password`, `status`, `role`, `email`, `name`) VALUES
(1, 'kelompokta', '$2y$10$DNPTBjHt5g6Pt1EsAicVmeF9TV6Pew7AtX9YA9lKunKe2IpbAriiG', 'approved', 'pengelola', 'kelompokta@gmail.com', 'Kelompok TA'),
(2, 'admin', '$2y$10$7pcmUhmtXaWcHGFAK8FQAucLNN095thexgFDexPNoHyaMgqIJEKKG', 'approved', 'admin', 'admin@gmail', 'Admin'),
(3, 'kelompok2', '$2y$10$9446HK8RXwGqcWy63oPVceL6LceWKBjBbw6.5fL8.dkQZwltqYrfi', 'approved', 'user', 'kelompok2@gmail.com', 'Kelompok 2'),
(4, 'tasya', '$2y$10$HkojZ9OnwKjlnv4rxBRuze9Y1LjOsd1NscYqX/vEUtJC7y5EyxXAi', 'approved', 'user', 'tasyadiva@gmail.com', 'Tasya'),
(5, 'cindy', '$2y$10$Db0bxOxh0wgTRVgjT5hYweK/zzIPTRCwxPFcpjZn54yluTAuB7h9C', 'rejected', 'admin', 'cindythresyasitumeang@gmail.com', 'Cindy'),
(6, 'kelompok', '$2y$10$yay2p7krr2jUQhH62epJsO3GZ.8dNorCnkDErUkHgpPu7GgNaZKT.', 'pending', 'user', 'kelompok@gmail.com', 'kelompok');

-- --------------------------------------------------------

--
-- Table structure for table `ruangan`
--

CREATE TABLE `ruangan` (
  `id_ruangan` int NOT NULL,
  `nama_ruangan` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ruangan`
--

INSERT INTO `ruangan` (`id_ruangan`, `nama_ruangan`, `status`) VALUES
(0, 'RMK', 'Tertutup'),
(412, 'RMK', 'Tertutup'),
(514, 'lab cisco', 'Tertutup'),
(527, 'Dantob', 'Tertutup');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_ruangan` (`id_ruangan`);

--
-- Indexes for table `jadwal_ruangan`
--
ALTER TABLE `jadwal_ruangan`
  ADD PRIMARY KEY (`id_jadwal`),
  ADD KEY `id_ruangan` (`id_ruangan`);

--
-- Indexes for table `registrations`
--
ALTER TABLE `registrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ruangan`
--
ALTER TABLE `ruangan`
  ADD PRIMARY KEY (`id_ruangan`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `jadwal_ruangan`
--
ALTER TABLE `jadwal_ruangan`
  MODIFY `id_jadwal` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `registrations`
--
ALTER TABLE `registrations`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`id_ruangan`) REFERENCES `ruangan` (`id_ruangan`);

--
-- Constraints for table `jadwal_ruangan`
--
ALTER TABLE `jadwal_ruangan`
  ADD CONSTRAINT `jadwal_ruangan_ibfk_1` FOREIGN KEY (`id_ruangan`) REFERENCES `ruangan` (`id_ruangan`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
