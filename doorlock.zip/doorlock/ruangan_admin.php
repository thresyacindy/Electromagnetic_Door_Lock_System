<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Ruangan</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 100%;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 4px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .container h2 {
            margin-top: 0;
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th, table td {
            padding: 12px 16px;
            text-align: left;
            border-bottom: 1px solid #ddd;
            vertical-align: middle; /* Ensures text is vertically centered */
        }

        table th {
            background-color: #f0f0f0;
            font-weight: bold;
        }

        table td {
            background-color: #fff;
        }

        /* Adding space between rows */
        table tr + tr td {
            padding-top: 10px;
            padding-bottom: 10px;
        }

        .dashboard-btn-container {
            margin-top: 20px;
            text-align: center;
        }

        .dashboard-btn {
            background-color: #4caf50;
            color: white;
            border: none;
            padding: 12px 24px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
            margin-right: 10px;
        }

        .action-btn {
            padding: 8px 12px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            border-radius: 4px;
            cursor: pointer;
            margin-right: 5px;
            transition: background-color 0.3s ease;
        }

        .action-btn i {
            margin-right: 5px;
        }

        .btn-view-detail {
            background-color: #007bff;
            color: white;
        }

        .btn-qr {
            background-color: #17a2b8;
            color: white;
        }

        .action-btn:hover {
            opacity: 0.8;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Daftar Ruangan</h2>
        <div class="page-line"></div>
        
        <div class='row'>        
            <div id="grid-system2" class="col-sm-12">
                <div class="box box-solid">
                    <div class="box-header with-border">
                        <h3 class="box-title">Daftar Ruangan yang Tersedia</h3>
                    </div>
                    <div id="grid-system2-body" class="box-body">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID Ruangan</th>
                                    <th>Nama Ruangan</th>
                                    <th>Status</th>
                                    <th>IP Device</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                require_once('config.php');
                                $sql = "SELECT * FROM ruangan";
                                $result = $conn->query($sql);

                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        echo "<tr>";
                                        echo "<td>" . $row["id_ruangan"] . "</td>";
                                        echo "<td>" . $row["nama_ruangan"] . "</td>";
                                        echo "<td>" . $row["status"] . "</td>";
                                        echo "<td>" . $row["ip_device"] . "</td>";
                                        echo "<td>";
                                        echo "<a href='view_detail.php?id=" . $row["id_ruangan"] . "' class='action-btn btn-view-detail'><i class='fas fa-eye'></i> View Detail</a>";
                                        echo "<button onclick='bukaRuangan(" . $row["id_ruangan"] . ")' class='action-btn btn-qr'><i class='fas fa-qrcode'></i> Generate QR</button>";
                                        echo "</td>";
                                        echo "</tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='5'>Tidak ada data yang tersedia</td></tr>";
                                }

                                $conn->close();
                                ?>
                            </tbody>
                        </table>
                        <div class="dashboard-btn-container">
                            <button class="dashboard-btn" onclick="window.location.href = 'index1.php';">Dashboard</button>
                            <button class="dashboard-btn" onclick="window.location.href = 'booking.php';">Booking</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function bukaRuangan(idRuangan) {
            fetch('generate_qr.php?id=' + idRuangan)
                .then(response => response.text())
                .then(qrCode => {
                    const qrPopup = window.open('', 'QR Code', 'width=300,height=300');
                    qrPopup.document.write(qrCode);
                })
                .catch(error => console.error('Error:', error));
        }
    </script>
</body>
</html>
