<?php
// Konfigurasi koneksi ke database
require_once('config.php');

// Pastikan ID booking dan tanggal kedaluwarsa diterima dari parameter URL
if (isset($_GET['id']) && !empty($_GET['id']) && isset($_GET['exp']) && !empty($_GET['exp'])) {
    $booking_id = mysqli_real_escape_string($conn, $_GET['id']);
    $expiration_date = mysqli_real_escape_string($conn, $_GET['exp']);

    // Query untuk mendapatkan tanggal kedaluwarsa berdasarkan ID
    $sql = "SELECT expiration_date FROM bookings WHERE id = '$booking_id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $stored_expiration_date = $row['expiration_date'];

        if ($expiration_date !== $stored_expiration_date) {
            echo 'invalid';
        } else {
            $currentDate = date('Y-m-d H:i:s');
            if ($stored_expiration_date < $currentDate) {
                echo 'expired';
            } else {
                echo 'valid';
            }
        }
    } else {
        echo 'not found';
    }

    // Tutup koneksi ke database
    $conn->close();
} else {
    echo 'not found';
}
?>