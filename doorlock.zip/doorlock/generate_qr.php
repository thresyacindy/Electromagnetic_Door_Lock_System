<?php
require_once('phpqrcode/qrlib.php'); // Sertakan library phpqrcode
require_once('config.php'); // Sertakan file konfigurasi database

// Periksa apakah parameter ID telah diterima
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Mengambil data pemesanan berdasarkan ID
    $sql = "SELECT * FROM bookings WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Data yang akan dimasukkan ke dalam QR code
        $data = json_encode([
            'id' => $row['id'],
            'nama' => $row['nama'],
            'email' => $row['email'],
            'tanggal_booking' => $row['tanggal_booking'],
            'waktu_mulai' => $row['waktu_mulai'],
            'waktu_selesai' => $row['waktu_selesai'],
            'ruangan' => $row['ruangan'],
            'expiration_date' => $row['expiration_date'],
        ]);

        // Buat file QR code sementara
        $tempDir = sys_get_temp_dir();
        $fileName = $tempDir . '/qrcode_' . $id . '.png';
        QRcode::png($data, $fileName);

        // Tampilkan gambar QR code
        header('Content-Type: image/png');
        readfile($fileName);

        // Hapus file sementara
        unlink($fileName);
    } else {
        echo "Data tidak ditemukan!";
    }

    $stmt->close();
    $conn->close();
} else {
    echo "ID tidak ditemukan!";
}
?>