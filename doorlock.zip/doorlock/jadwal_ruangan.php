<?php
// Konfigurasi koneksi ke database
require_once('config.php');

// Proses menambahkan jadwal jika form disubmit
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Mendapatkan data dari form
    $id_ruangan = $_POST["id_ruangan"];
    $tanggal = $_POST["tanggal"];
    $waktu_mulai = $_POST["waktu_mulai"];
    $waktu_selesai = $_POST["waktu_selesai"];
    $keterangan = $_POST["keterangan"];

    // Periksa apakah ruangan sudah dipesan pada waktu yang sama
    $sqlCheck = "SELECT * FROM jadwal_ruangan 
                 WHERE id_ruangan = ? AND tanggal = ? 
                 AND (waktu_mulai < ? AND waktu_selesai > ?)";
                 
    if ($stmtCheck = $conn->prepare($sqlCheck)) {
        $stmtCheck->bind_param("isss", $id_ruangan, $tanggal, $waktu_selesai, $waktu_mulai);
        $stmtCheck->execute();
        $resultCheck = $stmtCheck->get_result();

        if ($resultCheck->num_rows > 0) {
            echo "<script>alert('Ruangan sudah dipesan pada waktu yang dipilih.');</script>";
        } else {
            // Menyimpan data ke tabel jadwal_ruangan
            $sql = "INSERT INTO jadwal_ruangan (id_ruangan, tanggal, waktu_mulai, waktu_selesai, keterangan) 
                    VALUES (?, ?, ?, ?, ?)";

            if ($stmt = $conn->prepare($sql)) {
                $stmt->bind_param("issss", $id_ruangan, $tanggal, $waktu_mulai, $waktu_selesai, $keterangan);
                if ($stmt->execute()) {
                    $message = "Jadwal Ruangan berhasil dibuat.";
                    echo "<script>alert('$message');</script>";
                    header("Location: jadwal_ruangan.php");
                    exit();
                } else {
                    echo "Error: " . $stmt->error;
                }
                $stmt->close();
            } else {
                echo "Error preparing statement: " . $conn->error;
            }
        }
        $stmtCheck->close();
    } else {
        echo "Error preparing statement: " . $conn->error;
    }
}

// Ambil data ruangan untuk form
$query = "SELECT id_ruangan, nama_ruangan FROM ruangan";
$result = $conn->query($query);

// Ambil data jadwal untuk ditampilkan
$queryJadwal = "SELECT j.id_jadwal, r.nama_ruangan, j.tanggal, j.waktu_mulai, j.waktu_selesai, j.keterangan
                FROM jadwal_ruangan j
                JOIN ruangan r ON j.id_ruangan = r.id_ruangan
                WHERE j.keterangan = 'tersedia' 
                ORDER BY j.tanggal, j.waktu_mulai ASC";
$resultJadwal = $conn->query($queryJadwal);

// Update status jadwal setelah diambil
$updateStatusQuery = "UPDATE jadwal_ruangan SET keterangan = 'tidak tersedia' WHERE id_jadwal = ?";
$stmtUpdate = $conn->prepare($updateStatusQuery);
$stmtUpdate->bind_param("i", $id_jadwal);
$stmtUpdate->execute();
$stmtUpdate->close();

// Tutup koneksi
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Jadwal Ruangan</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            width: 100%;
            max-width: 800px;
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .container h2 {
            margin-bottom: 20px;
            font-size: 24px;
            text-align: center;
            color: #333;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 8px;
            color: #555;
        }

        .form-group input[type="text"],
        .form-group input[type="date"],
        .form-group input[type="time"],
        .form-group select {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            transition: border-color 0.3s;
        }

        .form-group input[type="text"]:focus,
        .form-group input[type="date"]:focus,
        .form-group input[type="time"]:focus,
        .form-group select:focus {
            border-color: #4caf50;
            outline: none;
        }

        .buttons {
            display: flex;
            justify-content: space-between;
        }

        .form-group button,
        .dashboard-btn {
            background-color: #4caf50;
            color: white;
            border: none;
            padding: 12px 20px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .form-group button:hover,
        .dashboard-btn:hover {
            background-color: #45a049;
        }

        .dashboard-btn {
            margin-left: 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f4f4f4;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Jadwal Ruangan</h2>
        
        <!-- Form untuk menambah jadwal -->
        <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="POST">
            <div class="form-group">
                <label for="id_ruangan">Ruangan</label>
                <select id="id_ruangan" name="id_ruangan" required>
                    <option value="" disabled selected>Pilih Ruangan</option>
                    <?php
                    // Tampilkan opsi ruangan dari database
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<option value='" . $row['id_ruangan'] . "'>" . $row['nama_ruangan'] . "</option>";
                        }
                    } else {
                        echo "<option value='' disabled>Tidak ada ruangan tersedia</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="tanggal">Tanggal</label>
                <input type="date" id="tanggal" name="tanggal" required>
            </div>
            <div class="form-group">
                <label for="waktu_mulai">Waktu Mulai</label>
                <input type="time" id="waktu_mulai" name="waktu_mulai" required>
            </div>
            <div class="form-group">
                <label for="waktu_selesai">Waktu Selesai</label>
                <input type="time" id="waktu_selesai" name="waktu_selesai" required>
            </div>
            <div class="form-group">
                <label for="keterangan">Keterangan</label>
                <input type="text" id="keterangan" name="keterangan">
            </div>
            <div class="buttons">
                <button type="submit">Simpan</button>
                <button class="dashboard-btn" onclick="window.location.href = 'index2.php';">Kembali ke Dashboard</button>
            </div>
        </form>

        <!-- Menampilkan jadwal yang ada -->
        <h3>Daftar Jadwal Ruangan</h3>
        <?php
        // Menampilkan jadwal yang ada
        if ($resultJadwal->num_rows > 0) {
            echo "<table>";
            echo "<thead><tr><th>ID Jadwal</th><th>Nama Ruangan</th><th>Tanggal</th><th>Waktu Mulai</th><th>Waktu Selesai</th><th>Keterangan</th><th>Aksi</th></tr></thead>";
            echo "<tbody>";
        while ($row = $resultJadwal->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row["id_jadwal"] . "</td>";
            echo "<td>" . $row["nama_ruangan"] . "</td>";
            echo "<td>" . $row["tanggal"] . "</td>";
            echo "<td>" . $row["waktu_mulai"] . "</td>";
            echo "<td>" . $row["waktu_selesai"] . "</td>";
            echo "<td>" . $row["keterangan"] . "</td>";
            echo "<td>
                <a href='edit_jadwal.php?id_jadwal=" . $row['id_jadwal'] . "'>Edit</a> |
                <a href='hapus_jadwal.php?id_jadwal=" . $row['id_jadwal'] . "' onclick='return confirm(\"Apakah Anda yakin ingin menghapus jadwal ini?\");'>Hapus</a>
              </td>";
            echo "</tr>";
        }
        echo "</tbody>";
        echo "</table>";
    } else {
        echo "<p>Tidak ada jadwal yang tersedia.</p>";
    }
    ?>
    </div>
</body>
</html>
