<?php
// Periksa apakah data yang dibutuhkan telah dikirim dari formulir edit
if (isset($_POST['id_ruangan'], $_POST['nama_ruangan'], $_POST['ip_device'])) {
    // Ambil data dari formulir
    $id_ruangan = $_POST['id_ruangan'];
    $nama_ruangan = $_POST['nama_ruangan'];
    $ip_device = $_POST['ip_device'];

    // Konfigurasi koneksi ke database
    require_once('config.php');

    // Query untuk melakukan update data ruangan berdasarkan ID
    $sql = "UPDATE ruangan SET nama_ruangan = '$nama_ruangan', ip_device = '$ip_device' WHERE id_ruangan = '$id_ruangan'";

    // Jalankan query
    if ($conn->query($sql) === TRUE) {
        // Jika query berhasil dijalankan, arahkan pengguna kembali ke halaman tampilan_ruangan.php
        header("Location: ruangan2.php");
        exit(); // Hentikan eksekusi script
    } else {
        // Jika query gagal dijalankan, tampilkan pesan kesalahan
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Tutup koneksi ke database
    $conn->close();
} else {
    // Jika data yang dibutuhkan tidak tersedia, tampilkan pesan kesalahan
    echo "<p>Data yang dibutuhkan tidak lengkap.</p>";
}
?>
